# src/run_queries.py

import os
import pandas as pd
from sqlalchemy import create_engine, text

# ---------------- Database connection ----------------
DATABASE_PATH = "../data/cricket_matches.db"
engine = create_engine(f"sqlite:///{DATABASE_PATH}", echo=False)

# Create results folder
os.makedirs("../data/results", exist_ok=True)

# ---------------- Queries with proper aliases ----------------
queries = {
    "top_10_batsmen_ODI": """
        SELECT d.batsman, SUM(d.runs) AS total_runs
        FROM deliveries d
        JOIN odi_matches m ON d.match_id = m.match_id
        GROUP BY d.batsman
        ORDER BY total_runs DESC
        LIMIT 10;
    """,
    "leading_wicket_takers_T20": """
        SELECT d.bowler, COUNT(*) AS wickets
        FROM deliveries d
        JOIN t20_matches m ON d.match_id = m.match_id
        WHERE d.dismissal_kind IS NOT NULL
        GROUP BY d.bowler
        ORDER BY wickets DESC
        LIMIT 10;
    """,
    "team_highest_win_pct_Test": """
        SELECT m.winner AS team, COUNT(*)*100.0 / (SELECT COUNT(*) FROM test_matches) AS win_pct
        FROM test_matches m
        GROUP BY m.winner
        ORDER BY win_pct DESC
        LIMIT 10;
    """,
    "total_centuries": """
        SELECT d.match_id, d.batsman, SUM(d.runs) AS runs
        FROM deliveries d
        GROUP BY d.match_id, d.batsman
        HAVING runs >= 100;
    """,
    "narrowest_victory": """
        SELECT m.match_id, m.winner, m.result_margin, m.result
        FROM (
            SELECT * FROM test_matches
            UNION ALL
            SELECT * FROM odi_matches
            UNION ALL
            SELECT * FROM t20_matches
        ) m
        WHERE m.result_margin IS NOT NULL
        ORDER BY CAST(m.result_margin AS INTEGER) ASC
        LIMIT 10;
    """,
    "most_sixes_T20": """
        SELECT d.batsman, COUNT(*) AS sixes
        FROM deliveries d
        JOIN t20_matches m ON d.match_id = m.match_id
        WHERE d.runs = 6
        GROUP BY d.batsman
        ORDER BY sixes DESC
        LIMIT 10;
    """,
    "top_strike_rate_ODI": """
        SELECT d.batsman, SUM(d.runs)*100.0 / COUNT(*) AS strike_rate, COUNT(*) AS balls
        FROM deliveries d
        JOIN odi_matches m ON d.match_id = m.match_id
        GROUP BY d.batsman
        HAVING COUNT(*) >= 500
        ORDER BY strike_rate DESC
        LIMIT 10;
    """,
    "most_ducks": """
        SELECT sub.batsman, COUNT(*) AS ducks
        FROM (
            SELECT d.match_id, d.batsman, SUM(d.runs) AS runs
            FROM deliveries d
            GROUP BY d.match_id, d.batsman
            HAVING runs = 0
        ) sub
        GROUP BY sub.batsman
        ORDER BY ducks DESC
        LIMIT 10;
    """,
    "best_economy_ODI": """
        SELECT d.bowler, SUM(d.runs)*6.0/COUNT(*) AS economy
        FROM deliveries d
        JOIN odi_matches m ON d.match_id = m.match_id
        GROUP BY d.bowler
        HAVING COUNT(*) >= 500
        ORDER BY economy ASC
        LIMIT 10;
    """,
    "most_dot_balls": """
        SELECT d.bowler, COUNT(*) AS dot_balls
        FROM deliveries d
        WHERE d.runs = 0
        GROUP BY d.bowler
        ORDER BY dot_balls DESC
        LIMIT 10;
    """,
    "most_runs_single_ODI": """
        SELECT d.match_id, d.batting_team, SUM(d.runs) AS total_runs
        FROM deliveries d
        JOIN odi_matches m ON d.match_id = m.match_id
        GROUP BY d.match_id, d.batting_team
        ORDER BY total_runs DESC
        LIMIT 10;
    """,
    "teams_most_sixes_IPL": """
        SELECT d.batting_team AS team, COUNT(*) AS sixes
        FROM deliveries d
        JOIN t20_matches m ON d.match_id = m.match_id
        WHERE d.runs = 6
        GROUP BY d.batting_team
        ORDER BY sixes DESC
        LIMIT 10;
    """,
    "teams_most_extras": """
        SELECT d.batting_team AS team, SUM(d.extras) AS extras
        FROM deliveries d
        GROUP BY d.batting_team
        ORDER BY extras DESC
        LIMIT 10;
    """,
    "avg_runs_per_over": """
        SELECT m.match_format, AVG(d.total_runs)*6.0 AS runs_per_over
        FROM deliveries d
        JOIN (
            SELECT match_id, 'Test' AS match_format FROM test_matches
            UNION ALL
            SELECT match_id, 'ODI' AS match_format FROM odi_matches
            UNION ALL
            SELECT match_id, 'T20' AS match_format FROM t20_matches
        ) m ON d.match_id = m.match_id
        GROUP BY m.match_format;
    """,
    "top_partnership_ODI": """
        SELECT d.match_id, d.batsman, d.non_striker, SUM(d.runs) AS runs
        FROM deliveries d
        JOIN odi_matches m ON d.match_id = m.match_id
        GROUP BY d.match_id, d.batsman, d.non_striker
        ORDER BY runs DESC
        LIMIT 10;
    """,
    "players_most_dismissed_by_bowler": """
        SELECT d.bowler, d.batsman, COUNT(*) AS dismissals
        FROM deliveries d
        WHERE d.dismissal_kind IS NOT NULL
        GROUP BY d.bowler, d.batsman
        ORDER BY dismissals DESC
        LIMIT 10;
    """,
    "avg_powerplay_runs_T20": """
        SELECT AVG(d.total_runs) AS avg_powerplay_runs
        FROM deliveries d
        JOIN t20_matches m ON d.match_id = m.match_id
        WHERE d.over BETWEEN 0 AND 5;
    """,
    "super_over_matches": """
        SELECT DISTINCT d.match_id
        FROM deliveries d
        WHERE d.over >= 20
        ORDER BY d.match_id;
    """
}

# ---------------- Execute Queries ----------------
with engine.connect() as conn:
    for name, query in queries.items():
        print(f"\n📌 Running query: {name}")
        df = pd.read_sql(text(query), conn)
        print(df.head(10))
        # Save each query result to CSV
        df.to_csv(f"../data/results/{name}.csv", index=False)
        print(f"✅ Saved results to ../data/results/{name}.csv")
