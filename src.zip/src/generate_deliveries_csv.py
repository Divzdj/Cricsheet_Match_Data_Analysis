# src/generate_deliveries_csv.py
import os
import json
import pandas as pd

RAW_DIRS = ["../data/raw/ipl", "../data/raw/odi", "../data/raw/t20", "../data/raw/test"]
OUTPUT_CSV = "../data/transformed/deliveries.csv"

all_deliveries = []

def safe_get(d, key, default=None):
    if isinstance(d, dict):
        return d.get(key, default)
    return default

for folder in RAW_DIRS:
    if not os.path.exists(folder):
        print(f"⚠️ Folder missing: {folder}")
        continue

    files = [f for f in os.listdir(folder) if f.endswith(".json")]
    print(f"Found {len(files)} JSON files in {folder}")

    for file in files:
        path = os.path.join(folder, file)
        with open(path, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except Exception as e:
                print(f"⚠️ Could not read {path}: {e}")
                continue

        # Use match_id from JSON or filename
        match_id = safe_get(data, "info", {}).get("match_id", None)
        if not match_id:
            # fallback: extract numeric part from filename
            match_id = int(''.join(filter(str.isdigit, file)))

        innings_list = safe_get(data, "innings", [])
        if not isinstance(innings_list, list):
            print(f"⚠️ Skipping innings in {path}: not a list")
            continue

        for inning in innings_list:
            if not isinstance(inning, dict):
                print(f"⚠️ Skipping inning_data in {path}: not a dict")
                continue

            team_batting = safe_get(inning, "team", "")
            overs = safe_get(inning, "overs", [])
            if not isinstance(overs, list):
                print(f"⚠️ Skipping overs in {path}: not a list")
                continue

            for over_data in overs:
                over_number = safe_get(over_data, "over", None)
                deliveries = safe_get(over_data, "deliveries", [])
                if not isinstance(deliveries, list):
                    print(f"⚠️ Skipping deliveries in {path}: not a list")
                    continue

                for ball in deliveries:
                    delivery = {
                        "match_id": match_id,
                        "inning": safe_get(inning, "inning", None),
                        "batting_team": team_batting,
                        "bowling_team": safe_get(ball, "bowling_team", ""),
                        "over": over_number,
                        "ball": safe_get(ball, "ball", None),
                        "batsman": safe_get(ball, "batter", ""),
                        "bowler": safe_get(ball, "bowler", ""),
                        "non_striker": safe_get(ball, "non_striker", ""),
                        "runs_batter": safe_get(safe_get(ball, "runs", {}), "batter", 0),
                        "runs_extras": safe_get(safe_get(ball, "runs", {}), "extras", 0),
                        "runs_total": safe_get(safe_get(ball, "runs", {}), "total", 0),
                        "extras_type": safe_get(ball, "extras_type", ""),
                        "player_dismissed": safe_get(ball, "player_dismissed", ""),
                        "dismissal_kind": safe_get(ball, "dismissal_kind", ""),
                        "fielder": safe_get(ball, "fielder", ""),
                    }
                    all_deliveries.append(delivery)

# Save to CSV
df = pd.DataFrame(all_deliveries)
df.to_csv(OUTPUT_CSV, index=False)
print(f"✅ deliveries.csv created with {len(df)} rows in {OUTPUT_CSV}")
