import os
import json
import pandas as pd

# Paths
RAW_DIR = "../data/raw"
TRANSFORMED_DIR = "../data/transformed"

# Ensure the transformed directory exists
os.makedirs(TRANSFORMED_DIR, exist_ok=True)

# Initialize lists to store match data
test_matches = []
odi_matches = []
t20_matches = []

# Iterate through match files
for match_type in ["test", "odi", "t20", "ipl"]:
    match_dir = os.path.join(RAW_DIR, match_type)
    if not os.path.exists(match_dir):
        continue
    
    for filename in os.listdir(match_dir):
        if filename.endswith(".json"):
            filepath = os.path.join(match_dir, filename)
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                
                # Add match type to data
                data['match_format'] = match_type

                # Separate by match type
                if match_type == "test":
                    test_matches.append(data)
                elif match_type == "odi":
                    odi_matches.append(data)
                elif match_type == "t20" or match_type == "ipl":
                    t20_matches.append(data)
            except Exception as e:
                print(f"⚠️ Error processing {filepath}: {e}")

# Convert lists to DataFrames
df_test = pd.DataFrame(test_matches)
df_odi = pd.DataFrame(odi_matches)
df_t20 = pd.DataFrame(t20_matches)

# Save DataFrames as CSV
df_test.to_csv(os.path.join(TRANSFORMED_DIR, "test_matches.csv"), index=False)
df_odi.to_csv(os.path.join(TRANSFORMED_DIR, "odi_matches.csv"), index=False)
df_t20.to_csv(os.path.join(TRANSFORMED_DIR, "t20_matches.csv"), index=False)

# Summary
print("✅ Data transformation complete!")
print(f"Total files processed: {len(test_matches) + len(odi_matches) + len(t20_matches)}")
print(f"Test matches: {len(test_matches)}")
print(f"ODI matches: {len(odi_matches)}")
print(f"T20 matches: {len(t20_matches)}")
