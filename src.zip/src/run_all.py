# src/run_all.py

import subprocess

scripts = [
    "database_setup.py",
    "data_transformation.py",
    "generate_deliveries_csv.py",
    "insert_data.py",
    "run_queries.py"  
]

for script in scripts:
    print(f"\n🚀 Running {script} ...\n")
    subprocess.run(["python", script], check=True)

print("\n✅ All scripts executed successfully!\n")
