import os
import requests
from zipfile import ZipFile
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

BASE_URL = "https://cricsheet.org/matches/"
SAVE_PATH = "data/raw"
MATCH_TYPES = ["test", "odi", "t20", "ipl"]

def make_folders():
    for m in MATCH_TYPES:
        folder = os.path.join(SAVE_PATH, m)
        os.makedirs(folder, exist_ok=True)

def start_browser():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

def get_zip_links(driver):
    """Use Selenium to get all match ZIP download links"""
    driver.get(BASE_URL)
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, "a"))
    )
    anchors = driver.find_elements(By.TAG_NAME, "a")
    links = [a.get_attribute("href") for a in anchors if a.get_attribute("href")]
    
    # Only keep links for Test, ODI, T20, IPL JSON ZIPs
    zip_links = {m: link for m in MATCH_TYPES if any(m in link.lower() and "json.zip" in link.lower() for link in links) 
                 for link in links if m in link.lower() and "json.zip" in link.lower()}
    return zip_links

def download_and_extract_zip(match_type, zip_url):
    folder = os.path.join(SAVE_PATH, match_type)
    os.makedirs(folder, exist_ok=True)

    # Skip if JSONs already exist
    existing_jsons = [f for f in os.listdir(folder) if f.endswith(".json")]
    if existing_jsons:
        print(f"Skipping {match_type} — already has {len(existing_jsons)} JSON files.")
        return

    zip_filename = zip_url.split("/")[-1]
    zip_path = os.path.join(SAVE_PATH, zip_filename)

    # Download ZIP
    print(f"Downloading {zip_filename} for {match_type}...")
    r = requests.get(zip_url, stream=True)
    with open(zip_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:
                f.write(chunk)
    print(f"Downloaded {zip_filename}")

    # Extract
    print(f"Extracting {zip_filename} to {folder}...")
    with ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(folder)
    print(f"Extracted {zip_filename}")

    # Remove ZIP
    os.remove(zip_path)
    print(f"Removed {zip_filename}\n")

if __name__ == "__main__":
    make_folders()
    browser = start_browser()
    try:
        zip_links = get_zip_links(browser)
        print(f"Found ZIP links for {len(zip_links)} match types: {list(zip_links.keys())}\n")

        for match_type, zip_url in zip_links.items():
            try:
                download_and_extract_zip(match_type, zip_url)
            except Exception as e:
                print(f"Failed {match_type}: {e}")
    finally:
        browser.quit()

    print("All match data downloaded and organized successfully!")
