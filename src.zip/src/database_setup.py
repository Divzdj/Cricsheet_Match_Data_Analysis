from sqlalchemy import Column, Integer, String, Float, JSON, create_engine
from sqlalchemy.orm import declarative_base

Base = declarative_base()

DATABASE_PATH = "../data/cricket_matches.db"
engine = create_engine(f"sqlite:///{DATABASE_PATH}", echo=False)

# ---------------- Test Matches Table ----------------
class TestMatch(Base):
    __tablename__ = "test_matches"

    match_id = Column(Integer, primary_key=True)
    match_date = Column(String)
    venue = Column(String)
    team1 = Column(String)
    team2 = Column(String)
    winner = Column(String)
    result = Column(String)
    result_margin = Column(String)
    toss_winner = Column(String)
    toss_decision = Column(String)
    player_of_match = Column(String)
    umpire1 = Column(String)
    umpire2 = Column(String)
    match_format = Column(String)

# ---------------- ODI Matches Table ----------------
class ODIMatch(Base):
    __tablename__ = "odi_matches"

    match_id = Column(Integer, primary_key=True)
    match_date = Column(String)
    venue = Column(String)
    team1 = Column(String)
    team2 = Column(String)
    winner = Column(String)
    result = Column(String)
    result_margin = Column(String)
    toss_winner = Column(String)
    toss_decision = Column(String)
    player_of_match = Column(String)
    umpire1 = Column(String)
    umpire2 = Column(String)
    match_format = Column(String)

# ---------------- T20 Matches Table ----------------
class T20Match(Base):
    __tablename__ = "t20_matches"

    match_id = Column(Integer, primary_key=True)
    match_date = Column(String)
    venue = Column(String)
    team1 = Column(String)
    team2 = Column(String)
    winner = Column(String)
    result = Column(String)
    result_margin = Column(String)
    toss_winner = Column(String)
    toss_decision = Column(String)
    player_of_match = Column(String)
    umpire1 = Column(String)
    umpire2 = Column(String)
    match_format = Column(String)

# ---------------- Delivery Table ----------------
class Delivery(Base):
    __tablename__ = "deliveries"

    delivery_id = Column(Integer, primary_key=True, autoincrement=True)
    match_id = Column(Integer)          # FK to match
    inning = Column(Integer)
    batting_team = Column(String)
    bowling_team = Column(String)
    over = Column(Integer)
    ball = Column(Integer)
    batsman = Column(String)
    bowler = Column(String)
    non_striker = Column(String)
    runs = Column(Integer)
    extras = Column(Integer)
    total_runs = Column(Integer)
    player_dismissed = Column(String)
    dismissal_kind = Column(String)
    fielder = Column(String)

# Create all tables
Base.metadata.create_all(engine)
print("✅ Tables created successfully!")
