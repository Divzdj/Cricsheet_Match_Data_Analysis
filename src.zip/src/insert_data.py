# src/insert_data.py

import os
import pandas as pd
from sqlalchemy.orm import Session
from database_setup import engine, TestMatch, ODIMatch, T20Match, Delivery

# Start session
session = Session(bind=engine)

def insert_csv_to_table(csv_path, table_class, batch_size=5000):
    if not os.path.exists(csv_path):
        print(f"⚠️ File not found: {csv_path}")
        return

    df = pd.read_csv(csv_path)
    table_columns = table_class.__table__.columns.keys()

    records = []
    for _, row in df.iterrows():
        data = {col: row[col] for col in table_columns if col in row}
        records.append(table_class(**data))

        if len(records) >= batch_size:
            session.bulk_save_objects(records)
            session.commit()
            records = []

    if records:
        session.bulk_save_objects(records)
        session.commit()

    print(f"✅ Inserted {len(df)} rows from {csv_path} into {table_class.__tablename__}")


# ---------------- Insert match-level data ----------------
insert_csv_to_table("../data/transformed/test_matches.csv", TestMatch)
insert_csv_to_table("../data/transformed/odi_matches.csv", ODIMatch)
insert_csv_to_table("../data/transformed/t20_matches.csv", T20Match)

# ---------------- Delivery-level data ----------------
deliveries_csv = "../data/transformed/deliveries.csv"
insert_csv_to_table(deliveries_csv, Delivery, batch_size=10000)  # bigger batch for faster insert

session.close()
print("🎉 All data inserted successfully!")
